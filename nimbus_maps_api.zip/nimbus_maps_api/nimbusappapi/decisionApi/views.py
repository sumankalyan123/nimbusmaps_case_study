from django.http import JsonResponse
from faker import Faker


def get_data(request):
    fake = Faker()
    UID = fake.random_number(digits=7)
    ADDRESS = fake.street_address()

    data = {
        'uid': UID,
        'address': ADDRESS

    }
    return JsonResponse(data)
