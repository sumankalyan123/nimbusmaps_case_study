from django.contrib import admin
from .models import sample_data

admin.site.register(sample_data)

# Register your models here.
